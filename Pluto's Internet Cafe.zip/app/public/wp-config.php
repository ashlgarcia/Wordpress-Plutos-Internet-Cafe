<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}


define('AUTH_KEY',         'Z+Zyt6Eyr8vEv0gqknDlnfb8Fj/cwRv9mpAY8iKW6sBc0jmbv5Knp+kbwI8sNtGTKphAaViHD1OJp8f1SiMBdQ==');
define('SECURE_AUTH_KEY',  'e2nrfe4W+tpkAv4pUJzZm6w1l6T5+RkNf0t6UvcX0BBzcwkE/gpu64Gad9EW99Ey2sz4+J9FBdHMHkr1DVwOmA==');
define('LOGGED_IN_KEY',    'ywKRVcspwJqaVk+8Yi1TBDhAAz6OfAebAKm3R/GzALafUcBmhMgF0KAzjLgKNQvPg3EeywEI5ZFcz5FQWWTISg==');
define('NONCE_KEY',        '3RmyDwj6CIhxsbFxIBPw7m9fFjLnxX1yomnvtBxg9Ol5kHCXHbvhmjvpSbARy4RFJuTi/+3Rh+Y9CESkRqJ5QA==');
define('AUTH_SALT',        'xBos2tZ93ZN/4iZIJH9HQ9MExXVOJjSqarS37XOEkbzdqM5TSU4V4TOjFCPeYDIR80rp0cFgatd+buC3HZ3n7Q==');
define('SECURE_AUTH_SALT', 'DD25qr7Ms3buiv/qyFpWqaspN3QDePggbsqg3zlnRcvkwqIojOhU3Q6kCByl8+PR0cwTM0pXuGMt8Z39LCw4aA==');
define('LOGGED_IN_SALT',   'tVpJzNSKQwy3+C+qO67PuLW/gRbh+gD0Mb7DSmZKvC6lXTxcV99vbi3FK4suRh6FOXxN5GuySL5QGVr0xbff7Q==');
define('NONCE_SALT',       'cptXJiaampyhen586A3g2bRYmtezr+F4KbGeHDmq6FpBzA/HSLwCGbJ7HcCRoA+xWLnLtzX1ZG8rb1tKxxD7Iw==');
define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
